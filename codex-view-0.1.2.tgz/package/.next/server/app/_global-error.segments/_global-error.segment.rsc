1:"$Sreact.fragment"
2:I[6952,[],""]
3:I[2206,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"zcCQoPr_eH4Q9Bi5Sd17w"}
