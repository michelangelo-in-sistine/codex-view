1:"$Sreact.fragment"
2:I[397,["314","static/chunks/314-b3f11cd5768ae20d.js","177","static/chunks/app/layout-5d0ca13cfeb627f6.js"],"AppHeader"]
3:I[6952,[],""]
4:I[2206,[],""]
:HL["/_next/static/css/5dfe8415b1db6f80.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/5dfe8415b1db6f80.css","precedence":"next"}]],["$","html",null,{"lang":"zh-CN","children":["$","body",null,{"className":"__variable_4eeef7 __variable_7b888a","children":["$","div",null,{"className":"mx-auto min-h-dvh w-full max-w-[1440px] px-4 py-6 lg:px-8","children":[["$","$L2",null,{}],["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}],["$","footer",null,{"className":"mt-10 border-t border-[color:var(--line)] pt-4 text-xs text-[var(--muted)]","children":"codex-view · 本地 JSONL 历史 -> SQLite 缓存 -> 可视化查看界面"}]]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"V97FGSrUBQaory-dQDdYR"}
