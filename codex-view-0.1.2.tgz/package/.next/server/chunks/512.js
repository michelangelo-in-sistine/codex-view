exports.id=512,exports.ids=[512],exports.modules={1964:(a,b,c)=>{"use strict";c.d(b,{Dx:()=>S,Cx:()=>X,GW:()=>T});var d=c(3024),e=c.n(d),f=c(1455),g=c.n(f),h=c(6760),i=c.n(h),j=c(481),k=c.n(j);function l(a){let b=/^(\d{4})-(\d{2})-(\d{2})$/.exec(a.trim());if(!b)return null;let c=Number(b[1]),d=Number(b[2]),e=Number(b[3]),f=new Date(c,d-1,e);return Number.isFinite(c)&&Number.isFinite(d)&&Number.isFinite(e)&&f.getFullYear()===c&&f.getMonth()===d-1&&f.getDate()===e?{year:c,month:d,day:e}:null}function m(a){if(!a)return;let b=a.trim();if(b)return l(b)?b:void 0}function n(a){let b=m(a.start),c=m(a.end);return b&&c&&b>c?{start:c,end:b}:{start:b,end:c}}var o=c(8161),p=c.n(o);function q(){return process.env.CODEX_SESSIONS_DIR??i().join(p().homedir(),".codex","sessions")}function r(){return process.env.CODEX_VIEW_CACHE_DIR??i().join(p().homedir(),".codex-view","cache")}var s=c(7550),t=c.n(s);let u=null;function v(){let a,b,c;return u||(a=r(),e().mkdirSync(a,{recursive:!0}),b=i().join(a,"index.sqlite"),(c=new(t())(b)).exec("PRAGMA journal_mode = WAL;"),c.exec("PRAGMA synchronous = NORMAL;"),c.exec("PRAGMA temp_store = MEMORY;"),u=c),u}function w(){let a=v();a.exec(`
    CREATE TABLE IF NOT EXISTS meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS files (
      file TEXT PRIMARY KEY,
      mtime_ms INTEGER NOT NULL,
      size INTEGER NOT NULL,
      session_id TEXT NOT NULL,
      session_name TEXT,
      first_user_prompt TEXT,
      daily_key TEXT NOT NULL,
      started_at TEXT,
      ended_at TEXT,
      duration_sec INTEGER,
      cwd TEXT,
      originator TEXT,
      cli_version TEXT,
      messages INTEGER NOT NULL,
      tool_calls INTEGER NOT NULL,
      errors INTEGER NOT NULL,
      tokens_total INTEGER NOT NULL DEFAULT 0,
      tokens_input INTEGER NOT NULL DEFAULT 0,
      tokens_output INTEGER NOT NULL DEFAULT 0,
      tokens_cached_input INTEGER NOT NULL DEFAULT 0,
      tokens_reasoning_output INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_files_session_id ON files(session_id);
    CREATE INDEX IF NOT EXISTS idx_files_daily_key ON files(daily_key);
    CREATE INDEX IF NOT EXISTS idx_files_started_at ON files(started_at);
    CREATE INDEX IF NOT EXISTS idx_files_ended_at ON files(ended_at);
    CREATE INDEX IF NOT EXISTS idx_files_cwd ON files(cwd);

    CREATE TABLE IF NOT EXISTS tool_counts (
      file TEXT NOT NULL,
      tool_name TEXT NOT NULL,
      count INTEGER NOT NULL,
      PRIMARY KEY (file, tool_name),
      FOREIGN KEY(file) REFERENCES files(file) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_tool_counts_tool_name ON tool_counts(tool_name);
  `);let b=a.prepare("PRAGMA table_info(files)").all();b.some(a=>"session_name"===a.name)||a.exec("ALTER TABLE files ADD COLUMN session_name TEXT;"),b.some(a=>"first_user_prompt"===a.name)||a.exec("ALTER TABLE files ADD COLUMN first_user_prompt TEXT;")}let x="timeline",y={startedAt:{expression:"started_at"},endedAt:{expression:"ended_at"},name:{expression:"COALESCE(session_name, first_user_prompt)",collation:"COLLATE NOCASE"},durationSec:{expression:"duration_sec"},cwd:{expression:"cwd",collation:"COLLATE NOCASE"},messages:{expression:"messages"},toolCalls:{expression:"tool_calls"},errors:{expression:"errors"},tokensTotal:{expression:"tokens_total"}},z=null,A=null,B=0;function C(a){return a.length?`WHERE ${a.join(" AND ")}`:""}function D(a,b="started_at"){let c=n(a),d=[],e=[];if(c.start){let a,f=(a=l(c.start))?new Date(a.year,a.month-1,a.day).toISOString():null;f&&(d.push(`${b} >= ?`),e.push(f))}if(c.end){let a,f=(a=l(c.end))?new Date(a.year,a.month-1,a.day+1).toISOString():null;f&&(d.push(`${b} < ?`),e.push(f))}return{conditions:d,params:e}}function E(a){try{return JSON.parse(a)}catch{return null}}function F(a){if("string"!=typeof a)return null;let b=new Date(a);return Number.isNaN(b.getTime())?null:b.toISOString()}function G(a){return"number"==typeof a&&Number.isFinite(a)?a:0}function H(a){return{total:G(a?.total_tokens),input:G(a?.input_tokens),output:G(a?.output_tokens),cachedInput:G(a?.cached_input_tokens),reasoningOutput:G(a?.reasoning_output_tokens)}}function I(a){return!!a&&(a.total>0||a.input>0||a.output>0||a.cachedInput>0||a.reasoningOutput>0)}async function J(a){await g().mkdir(a,{recursive:!0})}async function K(a){try{let b=await g().readFile(a,"utf8");return JSON.parse(b)}catch{return null}}async function L(a,b){let c=`${a}.tmp`;await g().writeFile(c,JSON.stringify(b,null,2),"utf8"),await g().rename(c,a)}async function M(a){let b=[];async function c(a){let d;try{d=await g().readdir(a,{withFileTypes:!0})}catch{return}for(let e of d){let d=i().join(a,e.name);e.isDirectory()?await c(d):e.isFile()&&e.name.endsWith(".jsonl")&&b.push(d)}}return await c(a),b}async function N(){let a,b=new Map;try{a=e().createReadStream(i().join(i().dirname(q()),"session_index.jsonl"),"utf8")}catch{return b}a.on("error",()=>void 0);let c=k().createInterface({input:a,crlfDelay:1/0});try{for await(let a of c){let c=E(a),d="string"==typeof c?.id?c.id:null,e="string"==typeof c?.thread_name?c.thread_name.trim():"";d&&e&&b.set(d,e)}}catch{}return b}async function O(a){var b;let c=i().basename(a,".jsonl"),d={},f={total:0,input:0,output:0,cachedInput:0,reasoningOutput:0},g=null,h=null,j=null,l={id:c,name:null,firstUserPrompt:null,file:a,startedAt:null,endedAt:null,durationSec:null,cwd:null,originator:null,cliVersion:null,messages:0,toolCalls:0,errors:0,tokensTotal:0,tokensInput:0,tokensOutput:0,tokensCachedInput:0,tokensReasoningOutput:0},m=e().createReadStream(a,"utf8");for await(let b of k().createInterface({input:m,crlfDelay:1/0})){let e=E(b);if(!e)continue;let i=F(e.timestamp);if(i&&(h||(h=i),j=i),"session_meta"===e.type){l=function(a,b,c){let d=c?.payload??{};return{id:d?.id??a,name:null,firstUserPrompt:null,file:b,startedAt:F(c?.timestamp)??F(d?.timestamp),endedAt:null,durationSec:null,cwd:"string"==typeof d?.cwd?d.cwd:null,originator:"string"==typeof d?.originator?d.originator:null,cliVersion:"string"==typeof d?.cli_version?d.cli_version:null,messages:0,toolCalls:0,errors:0,tokensTotal:0,tokensInput:0,tokensOutput:0,tokensCachedInput:0,tokensReasoningOutput:0}}(c,a,e),!h&&l.startedAt&&(h=l.startedAt);continue}if("event_msg"===e.type){let a=e.payload?.type;if("user_message"!==a||l.firstUserPrompt){if("turn_aborted"===a)l.errors+=1;else if("token_count"===a){let a=H(e.payload?.info?.total_token_usage),b=H(e.payload?.info?.last_token_usage),c=I(a),d=I(b);if(c){if(g){let c={total:Math.max(0,a.total-g.total),input:Math.max(0,a.input-g.input),output:Math.max(0,a.output-g.output),cachedInput:Math.max(0,a.cachedInput-g.cachedInput),reasoningOutput:Math.max(0,a.reasoningOutput-g.reasoningOutput)};f.total+=c.total,f.input+=c.input,f.output+=c.output,f.cachedInput+=c.cachedInput,f.reasoningOutput+=c.reasoningOutput,a.total<g.total&&d&&(f.total+=b.total,f.input+=b.input,f.output+=b.output,f.cachedInput+=b.cachedInput,f.reasoningOutput+=b.reasoningOutput)}else d&&(f.total+=b.total,f.input+=b.input,f.output+=b.output,f.cachedInput+=b.cachedInput,f.reasoningOutput+=b.reasoningOutput);g=a}else d&&(f.total+=b.total,f.input+=b.input,f.output+=b.output,f.cachedInput+=b.cachedInput,f.reasoningOutput+=b.reasoningOutput)}}else l.firstUserPrompt=function(a){if("string"!=typeof a)return null;let b=a.replace(/\s+/g," ").trim();if(!b)return null;let c=Array.from(b);return c.length<=160?b:`${c.slice(0,159).join("")}…`}(e.payload?.message);continue}if("response_item"!==e.type)continue;let k=e.payload??{},m=k.type;if("message"===m){let a=k.role;("user"===a||"assistant"===a)&&(l.messages+=1);continue}if("function_call"===m||"custom_tool_call"===m){let a="string"==typeof k.name?k.name:"unknown";l.toolCalls+=1,d[a]=(d[a]??0)+1;continue}if("function_call_output"===m||"custom_tool_call_output"===m){let a="string"==typeof k.output?k.output:null;if(a&&(/error|exception|traceback/i.test(a)&&(l.errors+=1),a.startsWith("{")))try{let b=JSON.parse(a),c=b?.metadata?.exit_code;"number"==typeof c&&0!==c&&(l.errors+=1)}catch{}}}if(l.startedAt=l.startedAt??h,l.endedAt=j,l.tokensTotal=f.total,l.tokensInput=f.input,l.tokensOutput=f.output,l.tokensCachedInput=f.cachedInput,l.tokensReasoningOutput=f.reasoningOutput,l.startedAt&&l.endedAt){let a=new Date(l.startedAt).getTime(),b=new Date(l.endedAt).getTime();Number.isNaN(a)||Number.isNaN(b)||!(b>=a)||(l.durationSec=Math.floor((b-a)/1e3))}return{sessionId:c,summary:l,dailyKey:(b=l.startedAt??h)?b.slice(0,10):"unknown",tokenUsage:f,tools:d}}async function P(){w();let a=v(),b=q(),c=r();await J(c),await J(i().join(c,x));let d=await M(b),e=await N(),f=new Set(d),h=Number(a.prepare("SELECT value FROM meta WHERE key='version'").get()?.value??0),j=a.prepare("SELECT mtime_ms as mtimeMs, size FROM files WHERE file = ?"),k=a.prepare("DELETE FROM files WHERE file = ?"),l=a.prepare("DELETE FROM tool_counts WHERE file = ?"),m=a.prepare(`
    INSERT INTO files (
      file, mtime_ms, size, session_id, daily_key, started_at, ended_at, duration_sec,
      cwd, originator, cli_version, first_user_prompt, messages, tool_calls, errors,
      tokens_total, tokens_input, tokens_output, tokens_cached_input, tokens_reasoning_output
    ) VALUES (
      @file, @mtimeMs, @size, @sessionId, @dailyKey, @startedAt, @endedAt, @durationSec,
      @cwd, @originator, @cliVersion, @firstUserPrompt, @messages, @toolCalls, @errors,
      @tokensTotal, @tokensInput, @tokensOutput, @tokensCachedInput, @tokensReasoningOutput
    )
    ON CONFLICT(file) DO UPDATE SET
      mtime_ms = excluded.mtime_ms,
      size = excluded.size,
      session_id = excluded.session_id,
      daily_key = excluded.daily_key,
      started_at = excluded.started_at,
      ended_at = excluded.ended_at,
      duration_sec = excluded.duration_sec,
      cwd = excluded.cwd,
      originator = excluded.originator,
      cli_version = excluded.cli_version,
      first_user_prompt = excluded.first_user_prompt,
      messages = excluded.messages,
      tool_calls = excluded.tool_calls,
      errors = excluded.errors,
      tokens_total = excluded.tokens_total,
      tokens_input = excluded.tokens_input,
      tokens_output = excluded.tokens_output,
      tokens_cached_input = excluded.tokens_cached_input,
      tokens_reasoning_output = excluded.tokens_reasoning_output
  `),n=a.prepare(`
    INSERT INTO tool_counts (file, tool_name, count)
    VALUES (?, ?, ?)
    ON CONFLICT(file, tool_name) DO UPDATE SET count = excluded.count
  `),o=a.prepare("UPDATE files SET session_name = ? WHERE file = ?");a.exec("BEGIN IMMEDIATE");try{for(let b of(2!==h&&a.exec("DELETE FROM tool_counts; DELETE FROM files;"),a.prepare("SELECT file FROM files").all()))f.has(b.file)||(l.run(b.file),k.run(b.file));for(let a of d){let b;try{b=await g().stat(a)}catch{continue}let c=j.get(a);if(c&&c.mtimeMs===b.mtimeMs&&c.size===b.size)continue;let d=await O(a);for(let[c,e]of(m.run({file:a,mtimeMs:b.mtimeMs,size:b.size,sessionId:d.sessionId,dailyKey:d.dailyKey,startedAt:d.summary.startedAt,endedAt:d.summary.endedAt,durationSec:d.summary.durationSec,cwd:d.summary.cwd,originator:d.summary.originator,cliVersion:d.summary.cliVersion,firstUserPrompt:d.summary.firstUserPrompt,messages:d.summary.messages,toolCalls:d.summary.toolCalls,errors:d.summary.errors,tokensTotal:d.tokenUsage.total,tokensInput:d.tokenUsage.input,tokensOutput:d.tokenUsage.output,tokensCachedInput:d.tokenUsage.cachedInput,tokensReasoningOutput:d.tokenUsage.reasoningOutput}),l.run(a),Object.entries(d.tools)))n.run(a,c,e)}for(let b of a.prepare("SELECT file, session_id as sessionId FROM files").all()){var p;o.run(e.get((p=b.sessionId,p.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)?.[0]??p))??null,b.file)}a.prepare("INSERT OR REPLACE INTO meta(key, value) VALUES ('sessionsDir', ?)").run(b),a.prepare("INSERT OR REPLACE INTO meta(key, value) VALUES ('generatedAt', ?)").run(new Date().toISOString()),a.prepare("INSERT OR REPLACE INTO meta(key, value) VALUES ('version', ?)").run(String(2)),a.exec("COMMIT")}catch(b){throw a.exec("ROLLBACK"),b}}function Q(a={}){w();let b=v(),c=r(),d=b.prepare("SELECT value FROM meta WHERE key='sessionsDir'").get()?.value??q(),e=b.prepare("SELECT value FROM meta WHERE key='generatedAt'").get()?.value??new Date().toISOString(),f=D(a),g=D(a,"f.started_at"),h=C([...f.conditions,"cwd IS NOT NULL AND cwd != ''"]),i=b.prepare(`
      SELECT
        COUNT(*) as files,
        COUNT(*) as sessions,
        COALESCE(SUM(messages), 0) as messages,
        COALESCE(SUM(tool_calls), 0) as toolCalls,
        COALESCE(SUM(errors), 0) as errors,
        COALESCE(SUM(tokens_total), 0) as tokensTotal,
        COALESCE(SUM(tokens_input), 0) as tokensInput,
        COALESCE(SUM(tokens_output), 0) as tokensOutput,
        COALESCE(SUM(tokens_cached_input), 0) as tokensCachedInput,
        COALESCE(SUM(tokens_reasoning_output), 0) as tokensReasoningOutput
      FROM files
      ${C(f.conditions)}
    `).get(...f.params),j=b.prepare(`
      SELECT
        daily_key as day,
        COUNT(*) as sessions,
        COALESCE(SUM(messages), 0) as messages,
        COALESCE(SUM(tool_calls), 0) as toolCalls,
        COALESCE(SUM(errors), 0) as errors,
        COALESCE(SUM(tokens_total), 0) as tokensTotal,
        COALESCE(SUM(tokens_input), 0) as tokensInput,
        COALESCE(SUM(tokens_output), 0) as tokensOutput,
        COALESCE(SUM(tokens_cached_input), 0) as tokensCachedInput,
        COALESCE(SUM(tokens_reasoning_output), 0) as tokensReasoningOutput
      FROM files
      ${C(f.conditions)}
      GROUP BY daily_key
    `).all(...f.params),k=b.prepare(`
      SELECT tc.tool_name as name, COALESCE(SUM(tc.count), 0) as count
      FROM tool_counts tc
      JOIN files f ON f.file = tc.file
      ${C(g.conditions)}
      GROUP BY tool_name
    `).all(...g.params),l=b.prepare(`
      SELECT
        cwd,
        COUNT(*) as sessions,
        COALESCE(SUM(tokens_total), 0) as tokensTotal
      FROM files
      ${h}
      GROUP BY cwd
      ORDER BY sessions DESC, tokensTotal DESC
      LIMIT 8
    `).all(...f.params),m={};for(let a of j)m[String(a.day)]={sessions:Number(a.sessions??0),messages:Number(a.messages??0),toolCalls:Number(a.toolCalls??0),errors:Number(a.errors??0),tokensTotal:Number(a.tokensTotal??0),tokensInput:Number(a.tokensInput??0),tokensOutput:Number(a.tokensOutput??0),tokensCachedInput:Number(a.tokensCachedInput??0),tokensReasoningOutput:Number(a.tokensReasoningOutput??0)};let n={};for(let a of k)n[String(a.name)]=Number(a.count??0);let o=l.map(a=>({cwd:String(a.cwd),sessions:Number(a.sessions??0),tokensTotal:Number(a.tokensTotal??0)}));return{version:2,generatedAt:e,sessionsDir:d,cacheDir:c,totals:{files:Number(i.files??0),sessions:Number(i.sessions??0),messages:Number(i.messages??0),toolCalls:Number(i.toolCalls??0),errors:Number(i.errors??0),tokensTotal:Number(i.tokensTotal??0),tokensInput:Number(i.tokensInput??0),tokensOutput:Number(i.tokensOutput??0),tokensCachedInput:Number(i.tokensCachedInput??0),tokensReasoningOutput:Number(i.tokensReasoningOutput??0)},tools:n,daily:m,workspaces:o}}async function R(){if(!(Date.now()-B<1e4)||!z){if(A)return void await A;A=(async()=>{await P(),z=Q(),B=Date.now()})().finally(()=>{A=null}),await A}}async function S(a={}){let b;return await R(),(b=n(a)).start||b.end?Q(n(a)):z??Q()}async function T(a){await R();let b=v(),c=Math.min(Math.max(a.limit??100,1),500),d=Math.max(a.offset??0,0),e=[],f=[],g=D(a);e.push(...g.conditions),f.push(...g.params),a.withTools&&e.push("tool_calls > 0"),a.withErrors&&e.push("errors > 0");let h=a.q?.trim();if(h){e.push("(session_id LIKE ? OR IFNULL(session_name, '') LIKE ? OR IFNULL(first_user_prompt, '') LIKE ? OR IFNULL(cwd, '') LIKE ? OR IFNULL(originator, '') LIKE ?)");let a=`%${h}%`;f.push(a,a,a,a,a)}let i=C(e),j=a.sortBy?y[a.sortBy]:null,k="asc"===a.sortOrder?"ASC":"DESC",l=j?[`(${j.expression} IS NULL)`,`${j.expression} ${j.collation??""} ${k}`.replace(/\s+/g," ").trim(),"(ended_at IS NULL)","ended_at DESC","session_id ASC"].join(",\n        "):"(COALESCE(ended_at, started_at) IS NULL),\n        COALESCE(ended_at, started_at) DESC,\n        started_at DESC,\n        session_id ASC",m=b.prepare(`SELECT COUNT(*) as count FROM files ${i}`).get(...f),n=b.prepare(`
      SELECT
        session_id as id,
        session_name as name,
        first_user_prompt as firstUserPrompt,
        file,
        started_at as startedAt,
        ended_at as endedAt,
        duration_sec as durationSec,
        cwd,
        originator,
        cli_version as cliVersion,
        messages,
        tool_calls as toolCalls,
        errors,
        tokens_total as tokensTotal,
        tokens_input as tokensInput,
        tokens_output as tokensOutput,
        tokens_cached_input as tokensCachedInput,
        tokens_reasoning_output as tokensReasoningOutput
      FROM files
      ${i}
      ORDER BY
        ${l}
      LIMIT ? OFFSET ?
    `).all(...f,c,d);return{generatedAt:new Date().toISOString(),total:Number(m.count??0),items:n.map(a=>({id:String(a.id),name:a.name??null,firstUserPrompt:a.firstUserPrompt??null,file:String(a.file),startedAt:a.startedAt??null,endedAt:a.endedAt??null,durationSec:a.durationSec??null,cwd:a.cwd??null,originator:a.originator??null,cliVersion:a.cliVersion??null,messages:Number(a.messages??0),toolCalls:Number(a.toolCalls??0),errors:Number(a.errors??0),tokensTotal:Number(a.tokensTotal??0),tokensInput:Number(a.tokensInput??0),tokensOutput:Number(a.tokensOutput??0),tokensCachedInput:Number(a.tokensCachedInput??0),tokensReasoningOutput:Number(a.tokensReasoningOutput??0)}))}}async function U(a){await R();let b=v().prepare(`
      SELECT
        session_id as id,
        session_name as name,
        first_user_prompt as firstUserPrompt,
        file,
        started_at as startedAt,
        ended_at as endedAt,
        duration_sec as durationSec,
        cwd,
        originator,
        cli_version as cliVersion,
        messages,
        tool_calls as toolCalls,
        errors,
        tokens_total as tokensTotal,
        tokens_input as tokensInput,
        tokens_output as tokensOutput,
        tokens_cached_input as tokensCachedInput,
        tokens_reasoning_output as tokensReasoningOutput
      FROM files
      WHERE session_id = ?
      LIMIT 1
    `).get(a);return b?{id:String(b.id),name:b.name??null,firstUserPrompt:b.firstUserPrompt??null,file:String(b.file),startedAt:b.startedAt??null,endedAt:b.endedAt??null,durationSec:b.durationSec??null,cwd:b.cwd??null,originator:b.originator??null,cliVersion:b.cliVersion??null,messages:Number(b.messages??0),toolCalls:Number(b.toolCalls??0),errors:Number(b.errors??0),tokensTotal:Number(b.tokensTotal??0),tokensInput:Number(b.tokensInput??0),tokensOutput:Number(b.tokensOutput??0),tokensCachedInput:Number(b.tokensCachedInput??0),tokensReasoningOutput:Number(b.tokensReasoningOutput??0)}:null}async function V(a){let b=await M(q()),c=b.find(b=>i().basename(b,".jsonl")===a);if(c)return c;for(let c of b){let b=e().createReadStream(c,"utf8");for await(let d of k().createInterface({input:b,crlfDelay:1/0})){let b=E(d);if(b?.type==="session_meta"&&b?.payload?.id===a)return c;break}}return null}async function W(a,b){let c=[],d=new Map,f=!1,g=null,h=e().createReadStream(a,"utf8");for await(let a of k().createInterface({input:h,crlfDelay:1/0})){let b=E(a);if(!b)continue;let e=F(b.timestamp)??"";if("event_msg"===b.type){let a=b.payload?.type;if("turn_aborted"===a)c.push({ts:e,kind:"error",text:"turn_aborted"});else if("token_count"===a){let a=H(b.payload?.info?.total_token_usage),d=H(b.payload?.info?.last_token_usage),f=I(a),h=I(d),i=null;f?(g?(i={total:Math.max(0,a.total-g.total),input:Math.max(0,a.input-g.input),output:Math.max(0,a.output-g.output),cachedInput:Math.max(0,a.cachedInput-g.cachedInput),reasoningOutput:Math.max(0,a.reasoningOutput-g.reasoningOutput)},a.total<g.total&&h&&(i.total+=d.total,i.input+=d.input,i.output+=d.output,i.cachedInput+=d.cachedInput,i.reasoningOutput+=d.reasoningOutput)):h&&(i={...d}),g=a):h&&(i={...d});let j=f?a:null,k=i&&I(i)?i:null;(j||k)&&c.push({ts:e,kind:"token_count",tokenUsage:{total:j,delta:k}})}}if("response_item"===b.type){let a=b.payload??{},f=a.type;if("message"===f){let b=a.role,d=function(a){let b=a?.content;if(!Array.isArray(b))return null;let c=[];for(let a of b)"string"==typeof a?.text&&c.push(a.text);return c.join("\n").trim()||null}(a)??"";"user"===b?c.push({ts:e,kind:"user",text:d}):"assistant"===b?c.push({ts:e,kind:"assistant",text:d,phase:"string"==typeof a.phase?a.phase:void 0}):c.push({ts:e,kind:"other",text:d})}else if("function_call"===f||"custom_tool_call"===f){let b="string"==typeof a.name?a.name:"unknown",f="string"==typeof a.call_id?a.call_id:null;f&&d.set(f,b);let g="string"==typeof a.arguments&&a.arguments||"string"==typeof a.input&&a.input||"";c.push({ts:e,kind:"tool_call",name:b,text:g,callId:f??void 0})}else if("function_call_output"===f||"custom_tool_call_output"===f){let b="string"==typeof a.call_id?a.call_id:null,f="string"==typeof a.name?a.name:b?d.get(b):void 0,g="string"==typeof a.output?a.output:"";c.push({ts:e,kind:"tool_output",name:f,text:g,callId:b??void 0})}}if(c.length>=5e3){f=!0;break}}return{summary:b,truncated:f,events:c}}async function X(a){var b;let c=await S(),d=await U(a),e=d?.file??await V(a);if(!e)return{summary:{id:a,name:null,firstUserPrompt:null,file:"",startedAt:null,endedAt:null,durationSec:null,cwd:null,originator:null,cliVersion:null,messages:0,toolCalls:0,errors:1,tokensTotal:0,tokensInput:0,tokensOutput:0,tokensCachedInput:0,tokensReasoningOutput:0},truncated:!1,events:[{ts:new Date().toISOString(),kind:"error",text:"session file not found"}]};let f=await g().stat(e),h=(b=c.cacheDir,i().join(b,x,`${encodeURIComponent(a)}.json`)),j=await K(h);if(j&&j.fileMtimeMs===f.mtimeMs&&j.fileSize===f.size&&"number"==typeof j.summary?.tokensTotal&&!j.events.some(a=>"token_count"===a.kind&&!a.tokenUsage?.delta))return{summary:j.summary,truncated:j.truncated,events:j.events};let k=d??(await O(e)).summary,l=await W(e,k);return await L(h,{...l,fileMtimeMs:f.mtimeMs,fileSize:f.size}),l}},5574:()=>{},8465:()=>{}};